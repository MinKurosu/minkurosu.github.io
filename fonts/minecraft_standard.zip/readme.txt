Faithful OpenType recreation of the Minecraft GUI font, with complete character set, few pixel fixes and some additional glyphs I felt were needed and where I knew how the glyph would look like in the game.

This font can be used for graphic designs, as a font on websites, or you can create Minecraft themed papers in word preprocessors, like MS Word or Libre Writer. The font is a little bit larger, so you may want to decrease the size a bit for a normal sized text.

License: CC PD
