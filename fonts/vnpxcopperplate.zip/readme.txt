本フォントはフリーフォントです。商用利用を含め、無料でご自由に使用することができます。
※再販売、再配布、複製を禁止します。

製作：三香白茶館
サークル代表：Veertig Nix


This font can be used freely for any purpose, including commercial use.
*Any reselling, redistribution and reproduction is prohibited.

Created by 三香白茶館(Sankoh Hakuchakan), organized by 40Nix
If you have any opinions or comments, please send them to DM on Twitter @40Nix.


Supported Unicode blocks: Basic Latin, Latin-1 Supplement, Latin Extended-A & some symbols

ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz 1234567890
!"#$%&'()*+,-./:;<=>?@{|}~¡¢£¥¦§¨©ª«¬®¯°±²³´¶·¸¹º»¼½¾¿
ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ
ĀāĂăĄąĆćĈĉĊċČčĎďĐđĒēĔĕĖėĘęĚěĜĝĞğĠġĢģĤĥĦħĨĩĪīĬĭĮįİıĲĳĴĵĶķĸĹĺĻļĽľĿŀŁłŃńŅņŇňŉŊŋŌōŎŏŐőŒœŔŕŖŗŘřŚśŜŝŞşŠšŢţŤťŦŧŨũŪūŬŭŮůŰűŲųŴŵŶŷŸŹźŻżŽž
―‘“€★☆♡♥♪♫♬


July 18 2023

Twitter:@40Nix
Email:veertig.nix@gmail.com