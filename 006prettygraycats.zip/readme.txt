﻿=== LEFT pretty cats Cursor Set ===

By: Funny Snowman (http://www.rw-designer.com/user/31157) ichiro.kano2@asahi.email.ne.jp

Download: http://www.rw-designer.com/cursor-set/006prettygraycats

Author's description:

Full set of LEFT version gray collor cat cursors.
Please visit Funny Snowman web site, if you want to get more animated cursors.
https://funnysnowman.com/index_e.html

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.